<html>
    
<head>
    <script>

    var scoreboard = function(){
        var score = 10;
        function returnScore() {
            return score;
        }
        return {
            getScore: returnScore
        }
    }()

    </script>
</head>
    <body>
        <div class="main">

        </div>
    </body>
</html>